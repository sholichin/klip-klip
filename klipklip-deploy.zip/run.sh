#!/usr/bin/env bash
# ==============================================================================
# KLIP KLIP — AI YouTube Viral Clipping & Monetization Studio
# ==============================================================================

set -e

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
cd "$DIR"

echo "=========================================================="
echo "⚡ KLIP KLIP — AI YouTube Viral Clipping Studio"
echo "=========================================================="

# Check Python environment
if [ -d "venv" ]; then
    PYTHON_EXEC="./venv/bin/python3"
else
    PYTHON_EXEC="python3"
fi

# Check FFmpeg binary
if [ -f "bin/ffmpeg" ]; then
    chmod +x bin/ffmpeg
    echo "✓ Local arm64 FFmpeg binary ready in bin/ffmpeg"
else
    echo "! Notice: Local bin/ffmpeg not found, using system ffmpeg if available."
fi

# Run FastAPI Server
echo "🚀 Menjalankan KLIP KLIP Web App di http://localhost:8000 ..."
exec $PYTHON_EXEC -m uvicorn app:app --host 0.0.0.0 --port 8000 --reload
