"""KLIP KLIP Core Package"""
__version__ = "1.0.0"
