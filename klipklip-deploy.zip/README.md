# ⚡ KLIP KLIP — AI YouTube Viral Clipping & Monetization Studio

Web application modern untuk automasi pembuatan video pendek vertikal (**Shorts, TikTok, Reels**) dari video YouTube berdurasi panjang, dioptimalkan khusus untuk kreator pemburu cuan di program reward klip seperti **MotionKlip**, **KlipReward**, dan TikTok Creator Rewards.

---

## 🌟 Fitur Unggulan KLIP KLIP

1. **AI Viral Moment Detector**
   - Menganalisis transkrip video menggunakan **Google Gemini API** (atau cerdas heuristik mode offline).
   - Mendeteksi 3–7 momen dengan potensi viral tertinggi (durasi ideal 30–60 detik).
   - Menghitung **Virality Score** (0–100) serta checklist kelayakan monetisasi.

2. **Headline Hook Overlay Otomatis**
   - Menghasilkan headline kontroversial & memancing rasa penasaran dalam 3 detik pertama (Stop-the-Scroll).
   - Pilihan visual banner: **Kuning Viral** (gaya MrBeast), **Merah Alert**, **Cyber Neon**, atau **Clean Minimalist**.
   - Dilengkapi tag identitas brand `KLIP KLIP • VIRAL`.

3. **Dynamic Karaoke Subtitles (TikTok / Alex Hormozi Style)**
   - Subtitle muncul per frasa pendek dengan kata aktif disorot (kuning / hijau / cyan) untuk memaksimalkan retensi penonton tanpa suara.

4. **9:16 Vertical Video Engine (1080x1920)**
   - **Mode Blurred Background**: Format paling populer untuk podcast & talkshow (video 16:9 di tengah dengan background atas-bawah blur estetik).
   - **Mode Center Crop**: Memotong sisi samping video untuk tampilan penuh vertikal.

5. **1-Click Paket Monetasi (MotionKlip & KlipReward Hub)**
   - 1-Klik Salin Judul Video Hook.
   - 1-Klik Salin Caption TikTok/Shorts yang memicu perdebatan komentar.
   - 1-Klik Salin Format Pengajuan Program Reward MotionKlip/KlipReward.
   - 1-Klik Download Video MP4 HD.

---

## 🚀 Cara Menjalankan Aplikasi

Pastikan Anda berada di direktori proyek:
```bash
./run.sh
```
Atau langsung jalankan dengan virtual environment:
```bash
./venv/bin/python3 -m uvicorn app:app --host 0.0.0.0 --port 8000 --reload
```

Buka browser Anda di:
👉 **http://localhost:8000**

---

## ⚙️ Konfigurasi API AI (Opsional)

Aplikasi dapat langsung digunakan tanpa API Key (menggunakan mesin deteksi heuristik cerdas bawaan).

Untuk hasil analisis transkrip tingkat lanjut:
1. Buka icon **Settings (⚙️)** di pojok kanan atas aplikasi.
2. Masukkan **Google Gemini API Key** Anda (bisa didapatkan gratis di [Google AI Studio](https://aistudio.google.com/app/apikey)).
3. Klik **Simpan Pengaturan**.
